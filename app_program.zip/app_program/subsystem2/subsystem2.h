/*
 * subsystem2.h
 * Buddy 2 -- Open-loop motor control. Student ID: 2500613.
 */

#ifndef SUBSYSTEM2_H
#define SUBSYSTEM2_H

#include "../app.h"
#include <stdint.h>

#define S2_PRI_MOTOR 14
#define S2_COMMAND_COUNT 8
#ifndef APP_S2_ONLY
#define APP_S2_ONLY 0
#endif

/* Refresh moving commands before this lease expires (milliseconds). */
#ifndef S2_COMMAND_TIMEOUT_MS
#define S2_COMMAND_TIMEOUT_MS 1000U
#endif

#if (S2_COMMAND_TIMEOUT_MS == 0) || (S2_COMMAND_TIMEOUT_MS > 2147483647U)
#error "S2_COMMAND_TIMEOUT_MS must fit a positive TMO value"
#endif

/* Per-wheel duty scaling (percent) to balance mismatched motors.
 * Lower the faster wheel's trim until FORWARD drives straight.
 * Motor 1 is the left wheel, motor 2 the right wheel.
 */
#ifndef S2_MOTOR1_TRIM_PERCENT
#define S2_MOTOR1_TRIM_PERCENT 97U
#endif

#ifndef S2_MOTOR2_TRIM_PERCENT
#define S2_MOTOR2_TRIM_PERCENT 98U
#endif

#if (S2_MOTOR1_TRIM_PERCENT == 0) || (S2_MOTOR1_TRIM_PERCENT > 100U) || \
    (S2_MOTOR2_TRIM_PERCENT == 0) || (S2_MOTOR2_TRIM_PERCENT > 100U)
#error "S2_MOTORx_TRIM_PERCENT must be 1..100"
#endif

/* Enable after confirming the encoder wiring in board_pins.h. */
#ifndef S2_ENCODER_ENABLED
#define S2_ENCODER_ENABLED 0
#endif

#if (S2_ENCODER_ENABLED != 0) && (S2_ENCODER_ENABLED != 1)
#error "S2_ENCODER_ENABLED must be 0 or 1"
#endif

typedef enum
{
    S2_MOVE_STOP,
    S2_MOVE_FORWARD,
    S2_MOVE_REVERSE,
    S2_MOVE_LEFT,        /* Rotate counterclockwise: left reverse, right forward. */
    S2_MOVE_RIGHT,       /* Rotate clockwise: left forward, right reverse. */
    S2_MOVE_PIVOT_RIGHT, /* Left wheel forward, right wheel stopped. */
    S2_MOVE_PIVOT_LEFT   /* Left wheel stopped, right wheel forward. */
} s2_move_command_t;

typedef struct
{
    T_MSG hdr; /* Kernel mailbox header must be first. */
    uint16_t motor; /* EDR motor word; no native enum layout in queued data. */
    int16_t steering; /* Internal signed permille correction; never published as EDR. */
    UW issued_at_ms;
    UW stop_epoch;
} s2_movement_msg_t;

typedef enum
{
    S2_MOTION_STOPPED,
    S2_MOTION_MOVING,
    S2_MOTION_FAULT
} s2_motion_state_t;

typedef struct
{
    s2_motion_state_t state;
    s2_move_command_t command;
    UINT power_percent;
    ER last_error; /* E_TMOUT means the movement command expired. */
    UW last_command_ms;
} s2_motion_status_t;

typedef struct
{
    /* Legacy field names refer to motor 2 (right wheel). */
    UW positive_pulses;
    UW negative_pulses;
    UW a_edges;
    UW b_edges;
    UINT a_level;
    UINT b_level;
    UW motor1_positive_pulses;
    UW motor1_negative_pulses;
    UW motor1_a_edges;
    UW motor1_b_edges;
    UINT motor1_a_level;
    UINT motor1_b_level;
    INT motor1_forward_counts;
    INT motor2_forward_counts;
    UINT valid; /* Zero until encoder initialization completes. */
    uint32_t sampled_ms; /* Boot milliseconds captured with this count copy. */
} s2_encoder_status_t;

IMPORT ER subsystem2_init(void);
IMPORT ER subsystem2_start(void);
IMPORT void s2_controller_bind(void);
IMPORT ER s2_emergency_stop(void);

/* Other subsystems submit expiring requests to the vehicle controller. */
IMPORT ER app_vehicle_request(UINT subsystem, s2_move_command_t command,
                              UINT power, UW lease_ms);

/* Task context only; moving commands need periodic renewal. */
IMPORT ER s2_movement_send(s2_move_command_t command, UINT power_percent);
IMPORT ER s2_follow_send(UINT power_percent, INT steering);
/* Reports commanded output, not measured wheel motion. Task context only. */
IMPORT ER s2_motion_get_status(s2_motion_status_t *p_status);
/* E_NOSPT and zeroed output when encoder diagnostics are disabled.
 * Enable with S2_ENCODER_ENABLED=1, in standalone or integrated builds.
 * Task context on either core. E_OK with valid=0 during startup.
 * Both wheels share a consistent cumulative x1 count snapshot (modulo 32 bits).
 * Forward signs follow the downloaded wiring: motor 1 negative, motor 2 positive.
 * GPIO levels are live samples; these counts do not provide PID or angle control.
 * sampled_ms is tk_get_otm().lo within the successful sequence-checked copy.
 * Clock errors return the error with a zeroed snapshot.
 */
IMPORT ER s2_encoder_get_status(s2_encoder_status_t *p_status);

#if APP_TEST
IMPORT void subsystem2_test(void);
#endif

#endif /* SUBSYSTEM2_H */
