/* Local settings: ignored by Git. Replace placeholders before flashing.
 * Pico W requires a 2.4 GHz network. Broker must be reachable on that network.
 */
#ifndef WIFI_SECRETS_H
#define WIFI_SECRETS_H

#define WIFI_SSID "TheWok"
#define WIFI_PASSWORD "qwerty123456"
#define MQTT_BROKER_IP "10.25.242.92"
#define MQTT_BROKER_PORT 1883
#define MQTT_CLIENT_ID    "robot-buddy1"
#define MQTT_TOPIC        "robot/heartbeat"

/* Optional authentication. NULL means the broker requires no credentials.
 * Plain MQTT over TCP; this configuration does not enable TLS.
 */
#define MQTT_USERNAME     NULL
#define MQTT_PASSWORD     NULL

#endif